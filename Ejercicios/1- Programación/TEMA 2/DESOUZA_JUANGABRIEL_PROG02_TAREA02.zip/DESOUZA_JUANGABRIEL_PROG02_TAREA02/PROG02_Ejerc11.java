
package com.cursodejava.prog02_ejerc1;
/*
JUAN GABRIEL DE SOUZA
DAM                             <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
PROG2_Ejerc7
30/10/2024
*/
public class PROG02_Ejerc11 {
    public static void main (String[] args){
    char letra1 = 'B';
    char letra2 = 'K';
    
    int unicodeLetra1 = letra1;
    int unicodeLetra2 = letra2;
    
        System.out.println("La letra "+letra1+" corresponde al valor "+unicodeLetra1);
        System.out.println("La letra "+letra2+" corresponde al valor "+unicodeLetra2);
        
    }
}
