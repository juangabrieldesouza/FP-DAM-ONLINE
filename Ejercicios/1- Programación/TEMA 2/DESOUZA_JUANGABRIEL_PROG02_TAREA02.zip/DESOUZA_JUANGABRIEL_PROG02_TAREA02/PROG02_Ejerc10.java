package com.cursodejava.prog02_ejerc1;
/*
JUAN GABRIEL DE SOUZA
DAM                             <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
PROG2_Ejerc7
30/10/2024
*/

public class PROG02_Ejerc10 {
     public static void main(String[] args){
        double numero1 = 2;
        double numero2 = 7;
        
        
        double resultado = (double) numero1 / numero2;
        
        
        System.out.printf("El resultado de la division es: %.2f\n", resultado);
    }
}
